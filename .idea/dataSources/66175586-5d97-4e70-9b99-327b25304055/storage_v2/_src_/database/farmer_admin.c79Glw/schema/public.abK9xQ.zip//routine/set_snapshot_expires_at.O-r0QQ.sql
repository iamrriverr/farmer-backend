create function set_snapshot_expires_at() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.expires_at IS NULL THEN
        NEW.expires_at = NEW.created_at + (NEW.retention_days || ' days')::INTERVAL;
    END IF;
    RETURN NEW;
END;
$$;

alter function set_snapshot_expires_at() owner to admin;

