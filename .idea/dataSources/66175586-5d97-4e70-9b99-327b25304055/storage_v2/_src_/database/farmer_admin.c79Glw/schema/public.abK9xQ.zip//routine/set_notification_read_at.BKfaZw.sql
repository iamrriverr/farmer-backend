create function set_notification_read_at() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.is_read = TRUE AND OLD.is_read = FALSE THEN
        NEW.read_at = NOW();
    END IF;
    RETURN NEW;
END;
$$;

alter function set_notification_read_at() owner to admin;

